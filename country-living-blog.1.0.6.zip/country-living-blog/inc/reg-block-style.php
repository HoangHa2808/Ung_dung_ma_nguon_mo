<?php
/**
 * Register Block Style
 */
register_block_style( 'core/quote', array(
	'name'         => 'red-qoute',
    'label'        => __( 'Red Quote', 'country-living-blog' ),
    'is_default'   => true,
));
