<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Country Living Blog
 */
get_template_part( 'template-parts/content/post', 'layout' );